# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['devops_console_rest_api',
 'devops_console_rest_api.api',
 'devops_console_rest_api.api.v1',
 'devops_console_rest_api.api.v1.endpoints',
 'devops_console_rest_api.clients',
 'devops_console_rest_api.core',
 'devops_console_rest_api.models',
 'devops_console_rest_api.server_stubs',
 'devops_console_rest_api.tests',
 'devops_console_rest_api.tests.api',
 'devops_console_rest_api.tests.api.v1',
 'devops_console_rest_api.tests.utils']

package_data = \
{'': ['*']}

install_requires = \
['aiobitbucket @ '
 'git+https://github.com/croixbleueqc/python-aiobitbucket.git@fastapi',
 'fastapi[all]>=0.75.2,<0.76.0',
 'passlib[bcrypt]>=1.7.4,<2.0.0',
 'pydantic>=1.9.0,<2.0.0',
 'pytest>=7.1.2,<8.0.0',
 'python-dotenv>=0.20.0,<0.21.0',
 'python-jose[cryptography]>=3.3.0,<4.0.0',
 'python-multipart>=0.0.5,<0.0.6',
 'requests>=2.27.1,<3.0.0',
 'uvicorn>=0.17.6,<0.18.0']

setup_kwargs = {
    'name': 'devops-console-rest-api',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Nicolas Epstein',
    'author_email': 'nicolas.epstein@qc.croixbleue.ca',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
